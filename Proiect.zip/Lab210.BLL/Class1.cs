﻿using System;

namespace Lab210.BLL
{
    public class Class1
    {
    }
}
