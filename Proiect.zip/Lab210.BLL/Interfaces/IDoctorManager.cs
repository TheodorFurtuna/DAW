﻿using Lab210.DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab210.BLL.Interfaces
{
    public interface IDoctorManager
    {
        Task<List<DoctorModel>> GetDoctori();
        Task<DoctorModel> GetDoctorById(int id);

        Task<DoctorModel> UpdateDoctor(DoctorModel doctorToUpdate);
        Task<DoctorModel> InsertDoctor(DoctorModel doctorToInsert);
        Task<DoctorModel> DeleteDoctor(DoctorModel doctorToDelete);
    }
}
