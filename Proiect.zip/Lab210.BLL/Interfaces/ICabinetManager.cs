﻿using Lab210.DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab210.BLL.Interfaces
{
    public interface ICabinetManager
    {
        Task<List<CabinetModel>> GetCabinete();
        Task<CabinetModel> GetCabinetById(int id);

        Task<CabinetModel> UpdateCabinet(CabinetModel cabinetToUpdate);
        Task<CabinetModel> InsertCabinet(CabinetModel cabinetToInsert);
        Task<CabinetModel> DeleteCabinet(CabinetModel cabinetToDelete);
    }
}
