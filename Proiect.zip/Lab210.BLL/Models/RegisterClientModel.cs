﻿using Lab210.DAL.Entities;
using Lab210.DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab210.BLL.Models
{
    public class RegisterClientModel
    {
        public RegisterModel registerModel { get; set; }
        public ClientModel clientModel { get; set; }

    }
}
