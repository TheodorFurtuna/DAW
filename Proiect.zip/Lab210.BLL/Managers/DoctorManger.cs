﻿using Lab210.BLL.Interfaces;
using Lab210.DAL.Entities;
using Lab210.DAL.Interfaces;
using Lab210.DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab210.BLL.Managers
{
    public class DoctorManager : IDoctorManager
    {
        private readonly IDoctorRepository _doctorRepo;

        public DoctorManager(IDoctorRepository doctorRepo)
        {
            _doctorRepo = doctorRepo;
        }

        public async Task<DoctorModel> DeleteDoctor(DoctorModel doctorToDelete)
        {
            var delete = new Doctor()
            {
                Id = doctorToDelete.Id,
                Nume = doctorToDelete.Nume,
                Prenume = doctorToDelete.Prenume,
                CabinetId = doctorToDelete.CabinetId
            };
            await _doctorRepo.Delete(delete);
            return doctorToDelete;
        }

        public async Task<DoctorModel> GetDoctorById(int id)
        {
            var doctor = await _doctorRepo.GetById(id);
            var doctorModel = new DoctorModel()
            {
                Id = doctor.Id,
                Nume = doctor.Nume,
                Prenume = doctor.Prenume,
                CabinetId = doctor.CabinetId
            };
            return doctorModel;
        }

        public  async Task<List<DoctorModel>> GetDoctori()
        {
            var doctori = await _doctorRepo.GetAll();
            var list = new List<DoctorModel>();
            foreach (var doctor in doctori)
            {
                list.Add(new DoctorModel()
                {
                    Id = doctor.Id,
                    Nume = doctor.Nume,
                    Prenume = doctor.Prenume,
                    CabinetId = doctor.CabinetId
                });
            }
            return list;
        }

        public async  Task<DoctorModel> InsertDoctor(DoctorModel doctorToInsert)
        {
            var insert = new Doctor()
            {
                Id = doctorToInsert.Id,
                Nume = doctorToInsert.Nume,
                Prenume = doctorToInsert.Prenume,
                CabinetId = doctorToInsert.CabinetId
            };
            await _doctorRepo.Create(insert);
            return doctorToInsert;
        }

        public async Task<DoctorModel> UpdateDoctor(DoctorModel doctorToUpdate)
        {
            var update = new Doctor()
            {
                Id = doctorToUpdate.Id,
                Nume = doctorToUpdate.Nume,
                Prenume = doctorToUpdate.Prenume,
                CabinetId = doctorToUpdate.CabinetId
            };
            await _doctorRepo.Update(update);
            return doctorToUpdate;
        }
    }
}
