﻿using Lab210.BLL.Interfaces;
using Lab210.DAL.Entities;
using Lab210.DAL.Interfaces;
using Lab210.DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab210.BLL.Managers
{
    public class ProgramareManager : IProgramareManager
    {
        private readonly IProgramareRepository _programareRepo;

        public ProgramareManager(IProgramareRepository programareRepo)
        {
            _programareRepo = programareRepo;
        }

        public async Task<ProgramareModel> DeleteProgramare(ProgramareModel programareToDelete)
        {
            var delete = new Programare()
            {
                Id = programareToDelete.Id,
                Plata = programareToDelete.Plata,
                Data = programareToDelete.Data,
                ClientId = programareToDelete.ClientId,
                DoctorId = programareToDelete.DoctorId
            };
            await _programareRepo.Delete(delete);
            return programareToDelete;
        }

        public async Task<ProgramareModel> GetProgramareById(int id)
        {
            var programare = await _programareRepo.GetById(id);
            var programareModel = new ProgramareModel()
            {
                Id = programare.Id,
                Plata = programare.Plata,
                Data = programare.Data,
                ClientId = programare.ClientId,
                DoctorId = programare.DoctorId
            };
            return programareModel;
        }

        public async Task<List<ProgramareModel>> GetProgramari()
        {
            var programari = await _programareRepo.GetAll();
            var list = new List<ProgramareModel>();
            foreach (var programare in programari)
            {
                list.Add(new ProgramareModel()
                {
                    Id = programare.Id,
                    Plata = programare.Plata,
                    Data = programare.Data,
                    ClientId = programare.ClientId,
                    DoctorId = programare.DoctorId
                });
            }
            return list;
        }

        public async Task<List<ProgramareModel>> GetProgramariByClientId(int clientId)
        {
            var programari = await _programareRepo.GetByClientId(clientId);
            var list = new List<ProgramareModel>();
            foreach(var programare in programari)
            {
                list.Add(new ProgramareModel()
                {
                    Id = programare.Id,
                    Plata = programare.Plata,
                    Data = programare.Data,
                    ClientId = programare.ClientId,
                    DoctorId = programare.DoctorId
                });
            }
            return list;
        }

        public async Task<List<ProgramareModel>> GetProgramariByDoctorId(int doctorId)
        {
            var programari = await _programareRepo.GetByDoctorId(doctorId);
            var list = new List<ProgramareModel>();
            foreach (var programare in programari)
            {
                list.Add(new ProgramareModel()
                {
                    Id = programare.Id,
                    Plata = programare.Plata,
                    Data = programare.Data,
                    ClientId = programare.ClientId,
                    DoctorId = programare.DoctorId
                });
            }
            return list;
        }

        public async Task<ProgramareModel> InsertProgramare(ProgramareModel programareToInsert)
        {
            var insert = new Programare()
            {
                Id = programareToInsert.Id,
                Plata = programareToInsert.Plata,
                Data = programareToInsert.Data,
                ClientId = programareToInsert.ClientId,
                DoctorId = programareToInsert.DoctorId
            };
            await _programareRepo.Create(insert);
            return programareToInsert;
        }

        public async Task<ProgramareModel> UpdateProgramare(ProgramareModel programareToUpdate)
        {
            var update = new Programare()
            {
                Id = programareToUpdate.Id,
                Plata = programareToUpdate.Plata,
                Data = programareToUpdate.Data,
                ClientId = programareToUpdate.ClientId,
                DoctorId = programareToUpdate.DoctorId
            };
            await _programareRepo.Update(update);
            return programareToUpdate;
        }
    }
}
