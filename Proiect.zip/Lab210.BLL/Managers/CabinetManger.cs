﻿using Lab210.BLL.Interfaces;
using Lab210.DAL.Entities;
using Lab210.DAL.Interfaces;
using Lab210.DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab210.BLL.Managers
{
    public class CabinetManager : ICabinetManager
    {
        private readonly ICabinetRepository _cabinetRepo;

        public CabinetManager(ICabinetRepository cabinetRepo)
        {
            _cabinetRepo = cabinetRepo;
        }

        public async Task<CabinetModel> DeleteCabinet(CabinetModel cabinetToDelete)
        {
            var delete = new Cabinet()
            {
                Id = cabinetToDelete.Id,
                Oras = cabinetToDelete.Oras,
                Adresa = cabinetToDelete.Adresa
            };
           await  _cabinetRepo.Delete(delete);
            return cabinetToDelete;
        }

        public async Task<CabinetModel> GetCabinetById(int id)
        {
            var cabinet = await _cabinetRepo.GetById(id);
            var cabinetModel = new CabinetModel()
            {
                Id = cabinet.Id,
                Oras = cabinet.Oras,
                Adresa = cabinet.Adresa
            };
            return cabinetModel;
        }

        public async Task<List<CabinetModel>> GetCabinete()
        {
            var cabinete = await _cabinetRepo.GetAll();
            var list = new List<CabinetModel>();
            foreach (var cabinet in cabinete)
            {
                list.Add(new CabinetModel()
                {
                    Id = cabinet.Id,
                    Oras = cabinet.Oras,
                    Adresa = cabinet.Adresa
                });
            }
            return list;
     
        }

        public async Task<CabinetModel> InsertCabinet(CabinetModel cabinetToInsert)
        {
            var insert = new Cabinet()
            {
                Id = cabinetToInsert.Id,
                Oras = cabinetToInsert.Oras,
                Adresa = cabinetToInsert.Adresa
            };
            await _cabinetRepo.Create(insert);
            return cabinetToInsert;
        }

        public async Task<CabinetModel> UpdateCabinet(CabinetModel cabinetToUpdate)
        {
            var update = new Cabinet()
            {
                Id = cabinetToUpdate.Id,
                Oras = cabinetToUpdate.Oras,
                Adresa = cabinetToUpdate.Adresa
            };
            await _cabinetRepo.Update(update);
            return cabinetToUpdate;
        }
    }
}
