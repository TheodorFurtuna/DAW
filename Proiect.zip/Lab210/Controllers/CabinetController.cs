﻿using Lab210.BLL.Interfaces;
using Lab210.DAL.Interfaces;
using Lab210.DAL.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lab210.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CabinetController : ControllerBase
    {
        private readonly ICabinetManager _cabinetManager;

        public CabinetController(ICabinetManager cabinetManager)
        {
            _cabinetManager = cabinetManager;
        }

        // autorizatii

        [AllowAnonymous]
        [HttpGet("get-all-cabinete")]
        public async Task<IActionResult> GetCabinete()
        {
            try 
            {
                var list = await _cabinetManager.GetCabinete();
                return Ok(list);
            }catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [Authorize("Client")]
        [HttpGet("get-cabinete-by-id/{id}")]
        public async Task<IActionResult> GetCabineteById(int id)
        {
            try
            {
                var cabinet = await _cabinetManager.GetCabinetById(id);
                return Ok(cabinet);
            }catch(Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [Authorize("Admin")]
        [HttpPost("insert-cabinet")]
        public async Task<IActionResult> InsertCabinet(CabinetModel cabinetModel)
        {try
            {
                var cabinet = await _cabinetManager.InsertCabinet(cabinetModel);
                return Ok(cabinet);
            }
            catch (Exception e) 
            { 
                return BadRequest(e.Message); 
            } 
        }

        [Authorize("Admin")]
        [HttpPut("update-cabinet")]
        public async Task<IActionResult> UpdateCabinet(CabinetModel cabinetModel)
        {
            try
            {
                var cabinet = await _cabinetManager.UpdateCabinet(cabinetModel);
                return Ok(cabinet);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [Authorize("Admin")]
        [HttpDelete("delete-cabinet")]
        public async Task<IActionResult> DeleteCabinet(CabinetModel cabinetModel)
        {
            try
            {
                var cabinet = await _cabinetManager.DeleteCabinet(cabinetModel);
                return Ok(cabinet);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }




    }
}
