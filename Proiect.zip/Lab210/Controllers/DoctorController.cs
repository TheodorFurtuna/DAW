﻿using Lab210.BLL.Interfaces;
using Lab210.DAL.Interfaces;
using Lab210.DAL.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lab210.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DoctorController : ControllerBase
    {
        private readonly IDoctorManager _doctorManager;

        public DoctorController(IDoctorManager doctorManager)
        {
            _doctorManager = doctorManager;
        }
        // autorizatii

        [AllowAnonymous]
        [HttpGet("get-all-doctori")]
        public async Task<IActionResult> GetDoctori()
        {
            try 
            {
                var list = await _doctorManager.GetDoctori();
                return Ok(list);
            }catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [AllowAnonymous]
        [HttpGet("get-doctori-by-id/{id}")]
        public async Task<IActionResult> GetDoctorById(int id)
        {
            try
            {
                var doctor = await _doctorManager.GetDoctorById(id);
                return Ok(doctor);
            }catch(Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [Authorize("Admin")]
        [HttpPost("insert-doctor")]
        public async Task<IActionResult> InsertDoctor(DoctorModel doctorModel)
        {
            try
            {
                var doctor = await _doctorManager.InsertDoctor(doctorModel);
                return Ok(doctor);
            }
            catch (Exception e) 
            { 
                return BadRequest(e.Message); 
            } 
        }

        [Authorize("Admin")]
        [HttpPut("update-doctor")]
        public async Task<IActionResult> UpdateDoctor(DoctorModel doctorModel)
        {
            try
            {
                var doctor = await _doctorManager.UpdateDoctor(doctorModel);
                return Ok(doctor);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [Authorize("Admin")]
        [HttpDelete("delete-doctor")]
        public async Task<IActionResult> DeleteDoctor(DoctorModel doctorModel)
        {
            try
            {
                var doctor = await _doctorManager.DeleteDoctor(doctorModel);
                return Ok(doctor);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }




    }
}
