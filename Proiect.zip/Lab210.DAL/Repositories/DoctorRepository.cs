﻿using Lab210.DAL.Entities;
using Lab210.DAL.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab210.DAL.Repositories
{
    public class DoctorRepository : IDoctorRepository
    {
        private readonly AppDbContext _context;

        public DoctorRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Doctor>> GetAll()
        {
            var doctori = await _context.Doctori.ToListAsync();
            return doctori;

        }

        public async Task<Doctor> GetById(int id)
        {
            var doctor = await _context.Doctori.FindAsync(id);
            return doctor;
        }

        public async Task Create(Doctor doctor)
        {
            await _context.Doctori.AddAsync(doctor);
            await _context.SaveChangesAsync();
        }

        public async Task Update(Doctor doctor)
        {
            _context.Doctori.Update(doctor);
            await _context.SaveChangesAsync();
        }

        public async Task Delete(Doctor doctor)
        {
            _context.Doctori.Remove(doctor);
            await _context.SaveChangesAsync();
        }

        private async Task<IQueryable<Doctor>> GetAllQuery()
        {
            var query = _context.Doctori.AsQueryable();
            return query;
        }

    }
}
