﻿using Lab210.DAL.Entities;
using Lab210.DAL.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab210.DAL.Repositories
{
    public class CabinetRepository : ICabinetRepository
    {
        private readonly AppDbContext _context;

        public CabinetRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Cabinet>> GetAll()
        {


            var cabinete = await _context.Cabinete.ToListAsync();
            return cabinete;

        }

        public async Task<Cabinet> GetById(int id)
        {
            var cabinet = await _context.Cabinete.FindAsync(id);
            return cabinet;
        }

        public async Task Create(Cabinet cabinet)
        {
            await _context.Cabinete.AddAsync(cabinet);
            await _context.SaveChangesAsync();
        }

        public async Task Update(Cabinet cabinet)
        {
            _context.Cabinete.Update(cabinet);
            await _context.SaveChangesAsync();
        }

        public async Task Delete(Cabinet cabinet)
        {
            _context.Cabinete.Remove(cabinet);
            await _context.SaveChangesAsync();
        }

        private async Task<IQueryable<Cabinet>> GetAllQuery()
        {
            var query = _context.Cabinete.AsQueryable();
            return query;
        }

    }
}
