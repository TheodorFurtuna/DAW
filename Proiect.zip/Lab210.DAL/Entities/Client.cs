﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab210.DAL.Entities
{
    public class Client
    {
        //PK
        public int Id { get; set; }
        public string Nume { get; set; }

        public string Prenume{ get; set; }

        public ICollection<Programare> Programari { get; set; }

        public int UserId { get; set; }
        public virtual User User { get; set; }

    }
}
