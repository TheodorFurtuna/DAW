﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab210.DAL.Entities
{
    public class Cabinet
    {
        //PK
        public int Id { get; set; }
        public string Oras { get; set; }

        public string Adresa { get; set; }

        public ICollection<Doctor> Doctori { get; set; }

    }
}
