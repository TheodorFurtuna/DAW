﻿using Lab210.DAL.Entities;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab210.DAL.Interfaces
{
    public interface IProgramareRepository
    {
        Task<IEnumerable<Programare>> GetAll();
        Task<Programare> GetById(int id);
        Task<List<Programare>> GetByDoctorId(int doctorId);
        Task<List<Programare>> GetByClientId(int clientId);
        Task Create(Programare programare);
        Task Update(Programare programare);
        Task Delete(Programare programare);
    }
}
