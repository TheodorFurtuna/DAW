﻿using Lab210.DAL.Entities;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab210.DAL.Interfaces
{
    public interface ICabinetRepository
    {
        Task<IEnumerable<Cabinet>> GetAll();
        Task<Cabinet> GetById(int id);
        Task Create(Cabinet cabinet);
        Task Update(Cabinet cabinet);
        Task Delete(Cabinet cabinet);
    }
}
